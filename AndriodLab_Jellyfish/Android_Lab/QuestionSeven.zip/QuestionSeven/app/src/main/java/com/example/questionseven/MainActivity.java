package com.example.questionseven;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Set up the toolbar
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        // Get ActionBar
        ActionBar actionBar = getSupportActionBar();

        if (actionBar != null) {
            // providing title for the ActionBar
           // actionBar.setTitle("GfG | Action Bar");

            // providing subtitle for the ActionBar
            //actionBar.setSubtitle("Design a custom Action Bar");

            // adding icon in the ActionBar
            actionBar.setIcon(R.drawable.app_logo);

            // methods to display the icon in the ActionBar
            actionBar.setDisplayUseLogoEnabled(true);
            actionBar.setDisplayShowHomeEnabled(true);
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.search) {
            Toast.makeText(this, "Search Clicked", Toast.LENGTH_SHORT).show();
            return true;
        } else if (id == R.id.refresh) {
            Toast.makeText(this, "Refresh Clicked", Toast.LENGTH_SHORT).show();
            return true;
        } else if (id == R.id.copy) {
            Toast.makeText(this, "Copy Clicked", Toast.LENGTH_SHORT).show();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
